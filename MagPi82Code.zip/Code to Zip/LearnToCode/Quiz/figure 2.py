chosen_phrase = random.choice(questions)
chosen_phrase = chosen_phrase.upper()
