import random

questions = ["As you like it", "The Tempest", "Measure for Measure",
             "Much Ado About Nothing", "The Comedy of Errors",
             "King Lear", "Cymbeline", "Hamlet", "Coriolanus", "Othello",
             "Love's Labour's Lost", "King John", "Julius Caesar", "Edward III"]
